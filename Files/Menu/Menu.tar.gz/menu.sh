#!/bin/bash
# Script by : FordSenpai
clear
echo 'echo -e "\e[0m                                                   "' >> .bashrc
echo 'echo -e "\e[94m    ::::::::::  ::::::::  :::::::::   ::::::::    "' >> .bashrc
echo 'echo -e "\e[94m    :+:        :+:    :+: :+:    :+:  :+:   :+:   "' >> .bashrc
echo 'echo -e "\e[94m    +:+        +:+    +:+ +:+    +:+  +:+   +:+   "' >> .bashrc
echo 'echo -e "\e[94m    +#+#+#+#:  +#+    +#: +#+ #+#++:  +#+   +:+   "' >> .bashrc
echo 'echo -e "\e[94m    +#+        +#+    +#+ +#+    +#+  +#+   +#+   "' >> .bashrc
echo 'echo -e "\e[94m    #+#        #+#    #+# #+#    #+#  #+#   #+#   "' >> .bashrc
echo 'echo -e "\e[94m    ###         ########  ###    ###  ########    "' >> .bashrc
echo 'echo -e "\e[91m             VPS Script by  FordSenpai            "' >> .bashrc
echo 'echo -e "\e[0m"'                                                    >> .bashrc
echo 'echo -e "\e[92m             [accounts/options/server]            "' >> .bashrc
echo 'echo -e "\e[0m                                                   "' >> .bashrc
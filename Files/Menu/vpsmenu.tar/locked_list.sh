#!/bin/bash
# Script by : FordSenpai
if [ -f "$FILE" ];
then
cd
nano /etc/Locked_List.txt
else
cd
nano /etc/Locked_List.txt
fi